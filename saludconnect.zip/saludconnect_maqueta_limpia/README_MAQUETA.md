# SaludConnectMX · Maqueta limpia para repositorio

Esta carpeta contiene una versión pública/mock del proyecto.

## Qué se limpió

- Sin API keys.
- Sin Mongo URL.
- Sin conexión a MongoDB, Kafka/Redpanda, Gemini, Ollama ni servicios externos obligatorios.
- Backend autocontenido con almacenamiento en memoria.
- Portal médico preparado para consumir la API desde la misma raíz (`API_BASE = ''`).
- Geolocalización externa sustituida por datos simulados locales.

## Ejecución

```bash
pip install fastapi uvicorn python-multipart
uvicorn main:app --reload
```

Abre:

```text
http://127.0.0.1:8000
```

## Usuario demo

El endpoint `/auth/login` acepta cualquier usuario en modo maqueta y devuelve un token no sensible.

## CURP demo sugerida

```text
DEMO930101HDFRSL09
```

También puedes buscar cualquier CURP y el backend generará un paciente demo en memoria.
