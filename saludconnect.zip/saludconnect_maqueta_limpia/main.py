"""
SaludConnectMX · API limpia para repositorio público
===================================================

Versión maqueta/autocontenida del backend.
- No usa MongoDB, Kafka/Redpanda, Gemini, Ollama ni archivos .env.
- No contiene API keys, tokens privados ni URLs de conexión.
- Mantiene endpoints compatibles con el portal médico para pruebas de interfaz.
- Usa almacenamiento en memoria; los datos se pierden al reiniciar el servidor.

Ejecución sugerida:
    uvicorn main_limpio_maqueta:app --reload
"""

from __future__ import annotations

import asyncio
import base64
import math
import random
import uuid
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import Body, FastAPI, Header, HTTPException, Request, Response, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


# -----------------------------------------------------------------------------
# Configuración general sin secretos
# -----------------------------------------------------------------------------
APP_DIR = Path(__file__).resolve().parent
PORTAL_CANDIDATES = [
    APP_DIR / "portal_medico_limpio_maqueta.html",
    APP_DIR / "portal_medico.html",
]

app = FastAPI(
    title="SaludConnectMX API · Maqueta limpia",
    description="Backend mock para pruebas del portal médico sin credenciales ni servicios externos.",
    version="0.1.0-public-mock",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

if APP_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(APP_DIR)), name="static")


# -----------------------------------------------------------------------------
# Almacenamiento en memoria
# -----------------------------------------------------------------------------
STORE: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
AUDIT_EVENTS: deque[Dict[str, Any]] = deque(maxlen=500)
AGENT_PENDING_ACTIONS: Dict[str, Dict[str, Any]] = {}
WS_CLIENTS: set[WebSocket] = set()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def make_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}"


def add_audit(action: str, resource: str = "System", detail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    event = {
        "id": make_id("audit"),
        "resourceType": "AuditEvent",
        "timestamp": now_iso(),
        "action": action,
        "resource": resource,
        "outcome": "0",
        "agent": [{"name": "usuario-demo", "requestor": True}],
        "detail": detail or {},
    }
    AUDIT_EVENTS.appendleft(event)
    return event


def as_list(collection: str) -> List[Dict[str, Any]]:
    return STORE[collection]


def subject_patient_id(doc: Dict[str, Any]) -> Optional[str]:
    for key in ("patient_id", "patientId", "paciente_id", "patient_curp", "patientCurp"):
        value = doc.get(key)
        if value:
            return str(value)
    subject = doc.get("subject") or doc.get("patient") or {}
    if isinstance(subject, dict):
        ref = subject.get("reference") or subject.get("id")
        if ref:
            return str(ref).split("/")[-1]
    return None


def matches_patient(doc: Dict[str, Any], patient_id: str) -> bool:
    patient_id = str(patient_id)
    candidates = {patient_id}
    for patient in STORE["Patient"]:
        if patient.get("id") == patient_id or patient.get("curp") == patient_id:
            candidates.add(str(patient.get("id")))
            candidates.add(str(patient.get("curp")))
            for identifier in patient.get("identifier", []):
                if isinstance(identifier, dict) and identifier.get("value"):
                    candidates.add(str(identifier["value"]))
    doc_patient = subject_patient_id(doc)
    return bool(doc_patient and doc_patient in candidates)


def ensure_json(payload: Any) -> Dict[str, Any]:
    if isinstance(payload, dict):
        return payload
    return {"value": payload}


def normalize_resource(collection: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    doc = dict(payload)
    doc.setdefault("id", make_id(collection.lower()))
    doc.setdefault("resourceType", collection)
    doc.setdefault("createdAt", now_iso())
    doc.setdefault("updatedAt", now_iso())
    return doc


def create_resource(collection: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    doc = normalize_resource(collection, payload)
    STORE[collection].append(doc)
    add_audit("C", collection, {"id": doc.get("id")})
    return doc


def get_patient_by_curp_or_id(value: str) -> Optional[Dict[str, Any]]:
    value = str(value).upper()
    for patient in STORE["Patient"]:
        identifiers = patient.get("identifier", [])
        identifier_values = [str(i.get("value", "")).upper() for i in identifiers if isinstance(i, dict)]
        if str(patient.get("id", "")).upper() == value or str(patient.get("curp", "")).upper() == value or value in identifier_values:
            return patient
    return None


def build_demo_patient(curp: str = "DEMO930101HDFRSL09") -> Dict[str, Any]:
    curp = (curp or "DEMO930101HDFRSL09").upper()
    return {
        "resourceType": "Patient",
        "id": f"patient-{curp[-6:].lower()}",
        "curp": curp,
        "identifier": [{"system": "urn:mx:curp", "value": curp}],
        "name": [{"text": "Paciente Demo SaludConnect", "given": ["Paciente"], "family": "Demo"}],
        "gender": "female",
        "birthDate": "1993-01-01",
        "telecom": [
            {"system": "phone", "value": "55 0000 0000"},
            {"system": "email", "value": "paciente.demo@example.local"},
        ],
        "address": [{"city": "Ciudad de México", "country": "México"}],
        "createdAt": now_iso(),
        "updatedAt": now_iso(),
    }


def seed_data() -> None:
    if STORE["Patient"]:
        return

    patient = build_demo_patient()
    STORE["Patient"].append(patient)
    pid = patient["id"]

    demo_observations = [
        ("Presion Arterial Sistólica", 128, "mmHg"),
        ("Frecuencia Cardiaca", 78, "lpm"),
        ("Temperatura", 36.7, "°C"),
        ("Saturacion Oxigeno SpO2", 97, "%"),
        ("Peso", 74, "kg"),
        ("Altura", 1.68, "m"),
        ("Actividad Fisica", 3, "sesiones/semana"),
        ("Hemoglobina Glucosilada HbA1c", 5.9, "%"),
        ("Glucosa", 104, "mg/dL"),
    ]
    for label, value, unit in demo_observations:
        STORE["Observation"].append({
            "resourceType": "Observation",
            "id": make_id("obs"),
            "status": "final",
            "code": {"text": label},
            "subject": {"reference": f"Patient/{pid}"},
            "valueQuantity": {"value": value, "unit": unit},
            "effectiveDateTime": now_iso(),
        })

    STORE["Condition"].append({
        "resourceType": "Condition",
        "id": make_id("cond"),
        "clinicalStatus": "active",
        "code": {"text": "Riesgo cardiometabólico moderado"},
        "subject": {"reference": f"Patient/{pid}"},
        "note": "Registro demo para pruebas de interfaz.",
        "createdAt": now_iso(),
    })
    STORE["MedicationRequest"].append({
        "resourceType": "MedicationRequest",
        "id": make_id("med"),
        "status": "active",
        "intent": "order",
        "medicationCodeableConcept": {"text": "Metformina 500 mg"},
        "subject": {"reference": f"Patient/{pid}"},
        "dosageInstruction": [{"text": "Una tableta cada 24 horas con alimento."}],
        "createdAt": now_iso(),
    })
    STORE["AllergyIntolerance"].append({
        "resourceType": "AllergyIntolerance",
        "id": make_id("alg"),
        "clinicalStatus": "active",
        "code": {"text": "Penicilina"},
        "type": "allergy",
        "reaction": [{"manifestation": [{"text": "Urticaria leve"}]}],
        "patient": {"reference": f"Patient/{pid}"},
        "createdAt": now_iso(),
    })
    STORE["Encounter"].append({
        "resourceType": "Encounter",
        "id": make_id("enc"),
        "status": "finished",
        "class": {"code": "AMB"},
        "subject": {"reference": f"Patient/{pid}"},
        "reasonCode": [{"text": "Consulta general demo"}],
        "note": [{"text": "Paciente estable. Seguimiento recomendado."}],
        "createdAt": now_iso(),
        "embedding": [0.12, 0.08, 0.44, 0.31],
    })
    STORE["Immunization"].append({
        "resourceType": "Immunization",
        "id": make_id("vac"),
        "status": "completed",
        "vaccineCode": {"text": "Influenza estacional"},
        "patient": {"reference": f"Patient/{pid}"},
        "occurrenceDateTime": datetime.now().date().isoformat(),
    })
    STORE["ImagingStudy"].append({
        "resourceType": "ImagingStudy",
        "id": make_id("img"),
        "status": "available",
        "subject": {"reference": f"Patient/{pid}"},
        "description": "Estudio demo sin imagen diagnóstica real.",
        "series": [{"instance": [{"title": "Radiografía demo", "data": ""}]}],
        "createdAt": now_iso(),
    })

    for idx in range(3):
        STORE["Appointment"].append({
            "id": make_id("appt"),
            "resourceType": "Appointment",
            "patient_id": pid,
            "patient_curp": patient["curp"],
            "patient_name": patient["name"][0]["text"],
            "date": (datetime.now() + timedelta(days=idx + 1)).date().isoformat(),
            "time": f"{9 + idx}:00",
            "duration_min": 30,
            "appointment_type": "consulta",
            "reason": "Seguimiento demo",
            "status": "booked",
            "doctor_agent": "dr-demo",
            "room": "Consultorio 1",
            "createdAt": now_iso(),
        })

    add_audit("R", "System", {"message": "Datos demo inicializados"})


@app.on_event("startup")
async def startup() -> None:
    seed_data()


# -----------------------------------------------------------------------------
# Modelos mínimos para endpoints predictivos/agente
# -----------------------------------------------------------------------------
class DatosPacientePredictivo(BaseModel):
    edad: float = Field(default=40)
    masa_corporal: float = Field(default=25)
    valor_hemoglobina_glucosilada: float = Field(default=5.6)


class DatosPacienteObesidad(BaseModel):
    edad: float = 40
    altura: Optional[float] = 1.70
    peso: Optional[float] = 75
    actividad_fisica: Optional[float] = 2
    genero_masculino: Optional[float] = 0


class DatosChat(BaseModel):
    mensaje: str = ""
    contexto_paciente: Dict[str, Any] = Field(default_factory=dict)


class DatosAgenteChat(BaseModel):
    mensaje: str = ""
    contexto_paciente: Dict[str, Any] = Field(default_factory=dict)
    paciente_id: Optional[str] = None


class DatosAgenteExecute(BaseModel):
    action_id: str
    confirmado: bool = False


class DatosAgentSectionExplain(BaseModel):
    mensaje: Optional[str] = None
    contexto_seccion: Dict[str, Any] = Field(default_factory=dict)


class AgentAgendaInterpretRequest(BaseModel):
    mensaje: str
    contexto_paciente: Optional[Dict[str, Any]] = None
    paciente_id: Optional[str] = None
    doctor_agent: Optional[str] = None


class HospitalQuestionRequest(BaseModel):
    pregunta: str
    limite: Optional[int] = 8


# -----------------------------------------------------------------------------
# Utilidades de respuesta IA mock
# -----------------------------------------------------------------------------
def clinical_mock_response(message: str, contexto: Optional[Dict[str, Any]] = None) -> str:
    message = (message or "").strip()
    contexto = contexto or {}
    nombre = contexto.get("nombre") or contexto.get("patient_name") or "el paciente activo"
    if not message:
        return "Modo maqueta activo. Puedo explicar secciones, preparar acciones y simular consultas clínicas sin usar IA externa."
    lower = message.lower()
    if "riesgo" in lower:
        return f"Con los datos demo de {nombre}, el riesgo estimado es moderado. Recomiendo revisar presión arterial, IMC y HbA1c antes de tomar decisiones clínicas."
    if "alerg" in lower:
        return f"En la maqueta se registra una alergia demo a penicilina con reacción leve. Valida el expediente real antes de indicar medicamentos."
    if "agenda" in lower or "cita" in lower:
        return "Puedo preparar una cita demo; en esta versión no se envían notificaciones reales ni se escribe en servicios externos."
    return f"Respuesta simulada para: “{message}”. Esta versión está aislada de servicios externos y usa datos mock."


def pending_action(tool: str, payload: Dict[str, Any], risk: str = "bajo") -> Dict[str, Any]:
    action_id = make_id("act")
    action = {
        "action_id": action_id,
        "tool": tool,
        "riesgo": risk,
        "requiere_confirmacion": True,
        "payload": payload,
        "createdAt": now_iso(),
    }
    AGENT_PENDING_ACTIONS[action_id] = action
    return action


def parse_patient_name(patient: Dict[str, Any]) -> str:
    names = patient.get("name") or []
    if names and isinstance(names[0], dict):
        return names[0].get("text") or " ".join(names[0].get("given", []) + [names[0].get("family", "")]).strip()
    return patient.get("curp", "Paciente")


# -----------------------------------------------------------------------------
# Rutas base y autenticación demo
# -----------------------------------------------------------------------------
@app.get("/", response_model=None)
async def root():
    for candidate in PORTAL_CANDIDATES:
        if candidate.exists():
            return FileResponse(str(candidate))
    return {"ok": True, "message": "API maqueta activa. Coloca portal_medico_limpio_maqueta.html junto a este archivo para servir la interfaz."}


@app.post("/auth/login")
async def login(request: Request) -> Dict[str, Any]:
    # Compatible con form-data/x-www-form-urlencoded y JSON.
    username = "demo"
    role = "medico"
    try:
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            data = await request.json()
        else:
            data = dict(await request.form())
        username = data.get("username") or data.get("usuario") or data.get("email") or "demo"
        role = data.get("role") or data.get("rol") or "medico"
    except Exception:
        pass

    add_audit("LOGIN", "Auth", {"username": username, "role": role})
    return {
        "access_token": "demo-token-sin-secreto",
        "token_type": "bearer",
        "username": username,
        "role": role,
        "mensaje": "Login demo aceptado. No se validan credenciales reales en la maqueta.",
    }


@app.get("/api/ia/estado")
async def estado_motor_ia(x_ai_engine: Optional[str] = Header(default="local")) -> Dict[str, Any]:
    return {
        "ok": True,
        "engine": x_ai_engine or "local",
        "motor_activo": "mock-local",
        "modelo": "maqueta-sin-servicios-externos",
        "requiere_api_key": False,
        "nota": "No usa Gemini, Ollama ni API keys.",
    }


# -----------------------------------------------------------------------------
# Endpoints FHIR mínimos
# -----------------------------------------------------------------------------
@app.get("/fhir/Patient/")
async def listar_pacientes(_count: Optional[int] = None) -> List[Dict[str, Any]]:
    items = list(STORE["Patient"])
    return items[:_count] if _count else items


@app.head("/fhir/Patient/")
async def head_pacientes() -> Response:
    return Response(status_code=200)


@app.post("/fhir/Patient/")
async def crear_paciente(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    payload = ensure_json(payload)
    curp = (payload.get("curp") or payload.get("identifier", [{}])[0].get("value") if payload.get("identifier") else None) or f"DEMO{random.randint(1000,9999)}"
    payload.setdefault("curp", str(curp).upper())
    payload.setdefault("identifier", [{"system": "urn:mx:curp", "value": payload["curp"]}])
    payload.setdefault("name", [{"text": payload.get("nombre") or payload.get("name_text") or "Paciente Nuevo Demo"}])
    return create_resource("Patient", payload)


@app.get("/fhir/Patient/{curp_or_id}")
async def obtener_paciente(curp_or_id: str) -> Dict[str, Any]:
    patient = get_patient_by_curp_or_id(curp_or_id)
    if not patient:
        # En modo maqueta se genera un paciente de prueba para facilitar capturas.
        patient = build_demo_patient(curp_or_id)
        STORE["Patient"].append(patient)
        add_audit("C", "Patient", {"id": patient["id"], "auto_demo": True})
    return patient


def collection_routes(collection: str):
    async def create(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
        return create_resource(collection, ensure_json(payload))

    async def get_by_patient(patient_id: str) -> List[Dict[str, Any]]:
        return [doc for doc in STORE[collection] if matches_patient(doc, patient_id)]

    return create, get_by_patient


for _collection in ["Observation", "AllergyIntolerance", "Encounter", "Immunization", "ImagingStudy", "MedicationRequest"]:
    _create, _get = collection_routes(_collection)
    app.post(f"/fhir/{_collection}/", name=f"crear_{_collection.lower()}")(_create)
    app.get(f"/fhir/{_collection}/{{patient_id}}", name=f"obtener_{_collection.lower()}_paciente")(_get)


@app.post("/fhir/Condition/")
async def crear_condition(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    return create_resource("Condition", ensure_json(payload))


@app.get("/fhir/Condition/all/list")
async def listar_condiciones_globales() -> List[Dict[str, Any]]:
    return list(STORE["Condition"])


@app.get("/fhir/Condition/{patient_id}")
async def obtener_condition_paciente(patient_id: str) -> List[Dict[str, Any]]:
    return [doc for doc in STORE["Condition"] if matches_patient(doc, patient_id)]


@app.get("/fhir/AuditEvent")
async def obtener_logs_auditoria(limit: int = 100) -> List[Dict[str, Any]]:
    return list(AUDIT_EVENTS)[:limit]


# -----------------------------------------------------------------------------
# Agenda, consentimientos y recordatorios
# -----------------------------------------------------------------------------
@app.post("/fhir/Appointment/")
async def crear_cita(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    doc = normalize_resource("Appointment", ensure_json(payload))
    doc.setdefault("status", "booked")
    doc.setdefault("doctor_agent", "dr-demo")
    STORE["Appointment"].append(doc)
    add_audit("C", "Appointment", {"id": doc["id"]})
    return doc


@app.get("/fhir/Appointment/patient/{patient_curp}")
async def obtener_citas_paciente(patient_curp: str) -> List[Dict[str, Any]]:
    patient_curp = patient_curp.upper()
    return [c for c in STORE["Appointment"] if str(c.get("patient_curp", "")).upper() == patient_curp]


@app.get("/fhir/Appointment/doctor/{doctor_agent}")
async def obtener_citas_medico(doctor_agent: str) -> List[Dict[str, Any]]:
    return [c for c in STORE["Appointment"] if str(c.get("doctor_agent", "dr-demo")) == doctor_agent or doctor_agent in ("demo", "dr-demo", "medico")]


@app.patch("/fhir/Appointment/{cita_id}")
async def actualizar_estado_cita(cita_id: str, payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    for cita in STORE["Appointment"]:
        if cita.get("id") == cita_id:
            cita.update(payload or {})
            cita["updatedAt"] = now_iso()
            add_audit("U", "Appointment", {"id": cita_id})
            return cita
    raise HTTPException(status_code=404, detail="Cita no encontrada en maqueta")


@app.get("/api/appointments/need-reminder")
async def citas_para_recordatorio() -> List[Dict[str, Any]]:
    return [c for c in STORE["Appointment"] if not c.get("reminder_sent")]


@app.patch("/api/appointments/{cita_id}/mark-reminder")
async def marcar_recordatorio(cita_id: str) -> Dict[str, Any]:
    for cita in STORE["Appointment"]:
        if cita.get("id") == cita_id:
            cita["reminder_sent"] = True
            cita["updatedAt"] = now_iso()
            return {"ok": True, "id": cita_id}
    raise HTTPException(status_code=404, detail="Cita no encontrada")


@app.post("/fhir/Consent/")
async def guardar_consentimiento(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    doc = create_resource("Consent", ensure_json(payload))
    doc["hash_demo"] = uuid.uuid5(uuid.NAMESPACE_URL, str(doc)).hex
    return doc


@app.get("/fhir/Consent/{paciente_curp}")
async def obtener_consentimientos(paciente_curp: str) -> List[Dict[str, Any]]:
    paciente_curp = paciente_curp.upper()
    return [c for c in STORE["Consent"] if str(c.get("paciente_curp", c.get("patient_curp", ""))).upper() == paciente_curp]


@app.get("/fhir/Consent/verify/{consent_id}")
async def verificar_integridad_consentimiento(consent_id: str) -> Dict[str, Any]:
    found = next((c for c in STORE["Consent"] if c.get("id") == consent_id), None)
    return {"id": consent_id, "integridad": bool(found), "modo": "mock"}


# -----------------------------------------------------------------------------
# Predicción y análisis mock
# -----------------------------------------------------------------------------
@app.post("/api/predict/hipertension")
async def predecir_hipertension(datos: DatosPacientePredictivo) -> Dict[str, Any]:
    edad_score = max(0, min(35, (datos.edad - 25) * 0.7))
    imc_score = max(0, min(35, (datos.masa_corporal - 22) * 2.1))
    hba1c_score = max(0, min(30, (datos.valor_hemoglobina_glucosilada - 5.2) * 14))
    riesgo = round(max(3, min(96, edad_score + imc_score + hba1c_score)), 1)
    return {
        "riesgo_porcentaje": riesgo,
        "categoria": "alto" if riesgo >= 70 else "moderado" if riesgo >= 40 else "bajo",
        "modelo": "mock-logico-sin-archivo-pickle",
        "factores": {"edad": datos.edad, "imc": datos.masa_corporal, "hba1c": datos.valor_hemoglobina_glucosilada},
    }


@app.post("/api/predict/obesidad")
async def predecir_obesidad(datos: DatosPacienteObesidad) -> Dict[str, Any]:
    peso = datos.peso or 75
    altura = datos.altura or 1.70
    imc = peso / max(altura * altura, 0.01)
    if imc >= 30:
        categoria = "Obesidad"
    elif imc >= 25:
        categoria = "Sobrepeso"
    elif imc >= 18.5:
        categoria = "Peso saludable"
    else:
        categoria = "Bajo peso"
    return {"categoria": categoria, "imc": round(imc, 1), "modelo": "mock-imc"}


@app.post("/api/predict/xray")
async def analizar_radiografia(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    image = payload.get("imagen_base64") or payload.get("image") or ""
    has_image = bool(image)
    return {
        "resultado": "Análisis radiológico simulado",
        "hallazgos": ["Sin patrón crítico detectado en modo maqueta", "Validar siempre con especialista"],
        "confianza": 0.74 if has_image else 0.0,
        "modo": "mock",
    }


# -----------------------------------------------------------------------------
# NLP, chat y modo agente sin IA externa
# -----------------------------------------------------------------------------
@app.post("/api/nlp/sintesis")
async def generar_sintesis_nlp(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    nombre = payload.get("nombre") or payload.get("patient_name") or "Paciente activo"
    return {
        "sintesis": f"Síntesis demo de {nombre}: signos vitales estables, riesgo moderado y seguimiento preventivo sugerido.",
        "alertas": ["Datos generados en maqueta", "No usar como criterio clínico real"],
    }


@app.post("/api/chat")
async def chat_clinico(datos: DatosChat) -> Dict[str, Any]:
    return {"respuesta": clinical_mock_response(datos.mensaje, datos.contexto_paciente), "modo": "mock"}


@app.post("/api/nlp/preview")
async def preview_nlp_hibrido(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    texto = payload.get("texto") or payload.get("mensaje") or ""
    return {
        "intencion": "accion_clinica" if any(k in texto.lower() for k in ["registra", "guarda", "agenda"]) else "consulta",
        "entidades": [],
        "normalizado": texto.strip(),
        "modo": "mock",
    }


@app.post("/api/agent/document/analyze")
async def analizar_pdf_agente(file: Optional[UploadFile] = File(default=None), payload: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    filename = file.filename if file else "documento_demo.pdf"
    return {
        "ok": True,
        "archivo": filename,
        "texto_extraido": "Texto clínico simulado. Glucosa 128 mg/dL. Colesterol 210 mg/dL.",
        "json_clinico": {
            "laboratorio": [
                {"nombre": "Glucosa", "valor": 128, "unidad": "mg/dL", "estado": "alto"},
                {"nombre": "Colesterol", "valor": 210, "unidad": "mg/dL", "estado": "alto"},
            ]
        },
        "modo": "mock",
    }


@app.post("/api/agent/section/explain")
async def explicar_seccion_agente(datos: DatosAgentSectionExplain) -> Dict[str, Any]:
    seccion = datos.contexto_seccion.get("titulo") or datos.contexto_seccion.get("section") or "esta sección"
    return {
        "respuesta": f"{seccion}: explicación simulada. La sección concentra datos clínicos, indicadores y acciones seguras para revisión humana.",
        "puntos_clave": ["Lectura contextual", "Sin escritura automática", "Validación por rol"],
    }


@app.post("/api/agent/chat")
async def chat_agente_clinico(datos: DatosAgenteChat) -> Dict[str, Any]:
    texto = datos.mensaje.lower()
    acciones: List[Dict[str, Any]] = []
    if any(k in texto for k in ["alerg", "penicilina"]):
        acciones.append(pending_action(
            "registrar_alergia",
            {
                "resourceType": "AllergyIntolerance",
                "clinicalStatus": "active",
                "code": {"text": "Penicilina"},
                "reaction": [{"manifestation": [{"text": "Urticaria leve"}]}],
                "patient": {"reference": f"Patient/{datos.paciente_id or 'demo'}"},
            },
            risk="alto",
        ))
    if any(k in texto for k in ["agenda", "cita"]):
        acciones.append(pending_action(
            "crear_cita",
            {
                "patient_id": datos.paciente_id or "demo",
                "patient_name": datos.contexto_paciente.get("nombre", "Paciente demo"),
                "date": (datetime.now() + timedelta(days=1)).date().isoformat(),
                "time": "10:00",
                "reason": "Cita preparada por agente mock",
            },
            risk="medio",
        ))
    return {
        "respuesta": clinical_mock_response(datos.mensaje, datos.contexto_paciente),
        "acciones": acciones,
        "pending_actions": acciones,
        "modo": "mock",
    }


@app.post("/api/agent/execute")
async def ejecutar_accion_agente(datos: DatosAgenteExecute) -> Dict[str, Any]:
    action = AGENT_PENDING_ACTIONS.get(datos.action_id)
    if not action:
        return {"ok": False, "detail": "Acción no encontrada o ya ejecutada"}
    if not datos.confirmado:
        return {"ok": False, "detail": "La acción requiere confirmación"}

    tool = action["tool"]
    payload = action["payload"]
    if tool == "registrar_alergia":
        result = create_resource("AllergyIntolerance", payload)
    elif tool == "crear_cita":
        result = normalize_resource("Appointment", payload)
        result.setdefault("status", "booked")
        STORE["Appointment"].append(result)
    else:
        result = {"ok": True, "tool": tool, "payload": payload}
    AGENT_PENDING_ACTIONS.pop(datos.action_id, None)
    return {"ok": True, "ejecutado": True, "resultado": result}


@app.get("/api/nlp/casos-similares/{consulta_id}")
async def buscar_casos_similares(consulta_id: str) -> Dict[str, Any]:
    cases = []
    for idx, enc in enumerate(STORE["Encounter"][:5], 1):
        cases.append({
            "id": enc.get("id"),
            "score": round(0.92 - idx * 0.06, 2),
            "resumen": enc.get("note", [{}])[0].get("text", "Caso demo similar") if isinstance(enc.get("note"), list) else str(enc.get("note", "Caso demo similar")),
        })
    return {"consulta_id": consulta_id, "casos": cases, "edges": [], "nodes": cases, "modo": "mock"}


@app.get("/api/patient-similarity/{patient_id}")
async def patient_similarity_network(patient_id: str) -> Dict[str, Any]:
    return {
        "patient_id": patient_id,
        "nodes": [
            {"id": patient_id, "label": "Paciente activo", "group": "actual"},
            {"id": "demo-1", "label": "Caso similar 1", "group": "similar"},
            {"id": "demo-2", "label": "Caso similar 2", "group": "similar"},
        ],
        "edges": [
            {"from": patient_id, "to": "demo-1", "score": 0.88},
            {"from": patient_id, "to": "demo-2", "score": 0.76},
        ],
    }


@app.post("/api/nlp/auditoria")
async def escanear_logs_ia(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    text = payload.get("logs_texto") or payload.get("texto") or ""
    riesgo = "alto" if any(k in text.lower() for k in ["sql", "brute", "failed", "ransom"]) else "bajo"
    return {"riesgo": riesgo, "hallazgos": ["Análisis de auditoría simulado"], "modo": "mock"}


# -----------------------------------------------------------------------------
# Auditoría geográfica y analítica mock
# -----------------------------------------------------------------------------
@app.post("/api/auditoria/geo_log")
async def guardar_geo_log(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    doc = normalize_resource("GeoAuditLog", ensure_json(payload))
    STORE["GeoAuditLog"].insert(0, doc)
    add_audit("C", "GeoAuditLog", {"id": doc["id"]})
    return {"ok": True, "id": doc["id"]}


@app.get("/api/auditoria/geo_logs")
async def obtener_geo_logs(limit: int = 50) -> List[Dict[str, Any]]:
    if not STORE["GeoAuditLog"]:
        STORE["GeoAuditLog"].append({
            "id": make_id("geo"),
            "ip": "192.168.1.20",
            "ciudad": "Ciudad de México",
            "pais": "México",
            "org": "Red Interna Demo",
            "lat": 19.4326,
            "lon": -99.1332,
            "nivel": "ok",
            "usuario": "demo",
            "hora": datetime.now().strftime("%H:%M"),
            "timestamp": now_iso(),
            "accion": "Acceso demo",
        })
    return STORE["GeoAuditLog"][:limit]


@app.get("/api/auditoria/analitica")
async def obtener_analitica_forense() -> Dict[str, Any]:
    return {
        "eventos_total": len(AUDIT_EVENTS),
        "riesgo_global": "controlado",
        "ips_sospechosas": [{"ip": "185.220.101.5", "eventos": 7, "nivel": "simulado"}],
        "acciones_recientes": list(AUDIT_EVENTS)[:10],
        "series": [
            {"hora": "09:00", "eventos": 12},
            {"hora": "10:00", "eventos": 18},
            {"hora": "11:00", "eventos": 9},
        ],
        "modo": "mock",
    }


@app.get("/api/auditoria/validar_cadena/{coleccion}")
async def validar_cadena_blockchain(coleccion: str) -> Dict[str, Any]:
    return {
        "coleccion": coleccion,
        "valida": True,
        "bloques_revisados": len(STORE.get(coleccion, [])),
        "modo": "hash-demo-sin-blockchain-real",
    }


# -----------------------------------------------------------------------------
# Farmacia, notificaciones y reportes mock
# -----------------------------------------------------------------------------
DEMO_FARMACIA = [
    {"id": "med-001", "nombre": "Paracetamol", "presentacion": "500 mg", "stock": 120, "caducidad": "2027-02-01"},
    {"id": "med-002", "nombre": "Metformina", "presentacion": "500 mg", "stock": 86, "caducidad": "2026-11-15"},
    {"id": "med-003", "nombre": "Losartán", "presentacion": "50 mg", "stock": 54, "caducidad": "2026-09-30"},
]


@app.get("/api/farmacia")
async def listar_farmacia(limit: int = 500) -> List[Dict[str, Any]]:
    return DEMO_FARMACIA[:limit]


@app.get("/api/farmacia/recetas-hoy")
async def recetas_hoy() -> List[Dict[str, Any]]:
    return [
        {"id": make_id("rx"), "paciente": "Paciente Demo", "medicamento": "Metformina 500 mg", "estado": "pendiente"},
        {"id": make_id("rx"), "paciente": "Paciente Demo", "medicamento": "Paracetamol 500 mg", "estado": "surtida"},
    ]


@app.get("/api/farmacia/buscar")
async def buscar_farmacia(q: str = "", limit: int = 100) -> List[Dict[str, Any]]:
    q_lower = q.lower().strip()
    items = [m for m in DEMO_FARMACIA if q_lower in m["nombre"].lower()] if q_lower else DEMO_FARMACIA
    return items[:limit]


@app.post("/api/notificaciones/enviar")
async def enviar_notificacion(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    return {"ok": True, "modo": "mock", "mensaje": "Notificación simulada; no se envió nada externo.", "payload": payload}


@app.post("/api/disparar-reporte")
async def disparar_reporte(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict[str, Any]:
    return {"ok": True, "reporte_id": make_id("rep"), "modo": "mock", "payload": payload}


# -----------------------------------------------------------------------------
# Agente: agenda y pregunta al hospital
# -----------------------------------------------------------------------------
@app.post("/api/agent/agenda/interpretar")
async def agent_agenda_interpretar(datos: AgentAgendaInterpretRequest) -> Dict[str, Any]:
    tomorrow = datetime.now() + timedelta(days=1)
    return {
        "intent": "crear_cita",
        "cita": {
            "patient_id": datos.paciente_id or "demo",
            "patient_name": (datos.contexto_paciente or {}).get("nombre", "Paciente demo"),
            "date": tomorrow.date().isoformat(),
            "time": "10:00",
            "duration_min": 30,
            "appointment_type": "consulta",
            "reason": datos.mensaje,
            "doctor_agent": datos.doctor_agent or "dr-demo",
        },
        "respuesta": "Agenda interpretada en modo maqueta. Revisa y confirma antes de guardar.",
        "modo": "mock",
    }


@app.get("/api/agent/data-quality")
async def agent_data_quality() -> Dict[str, Any]:
    total_patients = len(STORE["Patient"])
    return {
        "score": 92,
        "pacientes_revisados": total_patients,
        "hallazgos": [
            {"tipo": "completitud", "mensaje": "Datos demo suficientes para probar la UI"},
            {"tipo": "seguridad", "mensaje": "Sin conexiones externas ni credenciales"},
        ],
        "modo": "mock",
    }


@app.post("/api/agent/hospital-search")
async def agent_hospital_search(datos: HospitalQuestionRequest) -> Dict[str, Any]:
    pregunta = datos.pregunta.lower()
    if "cita" in pregunta:
        respuesta = f"Hay {len(STORE['Appointment'])} citas demo registradas."
    elif "paciente" in pregunta:
        respuesta = f"Hay {len(STORE['Patient'])} pacientes demo en memoria."
    elif "laboratorio" in pregunta or "alterado" in pregunta:
        respuesta = "Se detectan 2 resultados demo alterados: glucosa y colesterol."
    else:
        respuesta = "Consulta procesada sobre datos demo del hospital."
    return {
        "respuesta": respuesta,
        "resultados": list(AUDIT_EVENTS)[: max(1, min(datos.limite or 8, 20))],
        "modo": "mock",
    }


# -----------------------------------------------------------------------------
# WebSocket mock para syslog/SOC
# -----------------------------------------------------------------------------
@app.websocket("/ws/syslog")
async def websocket_syslog(websocket: WebSocket) -> None:
    await websocket.accept()
    WS_CLIENTS.add(websocket)
    try:
        await websocket.send_json({
            "timestamp": now_iso(),
            "priority": 5,
            "hostname": "EUS_DEMO_NODE",
            "message": "Syslog mock conectado",
            "src_ip": "192.168.1.20",
            "threat_level": 0,
            "threat_type": "info",
        })
        while True:
            await asyncio.sleep(10)
            await websocket.send_json({
                "timestamp": now_iso(),
                "priority": random.choice([4, 5, 6]),
                "hostname": "EUS_DEMO_NODE",
                "message": random.choice(["login ok", "port scan simulado", "failed login demo"]),
                "src_ip": f"192.168.1.{random.randint(2, 220)}",
                "threat_level": random.choice([0, 1, 2]),
                "threat_type": random.choice(["info", "failed_login", "port_scan"]),
            })
    except WebSocketDisconnect:
        pass
    finally:
        WS_CLIENTS.discard(websocket)


# -----------------------------------------------------------------------------
# Fallback controlado para endpoints GET/POST no implementados todavía.
# Evita romper la maqueta cuando el portal llame una ruta experimental.
# -----------------------------------------------------------------------------
@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def api_fallback(path: str, request: Request) -> JSONResponse:
    payload: Any = None
    try:
        payload = await request.json()
    except Exception:
        payload = None
    return JSONResponse({
        "ok": True,
        "modo": "mock-fallback",
        "endpoint": f"/api/{path}",
        "method": request.method,
        "payload_recibido": payload,
        "nota": "Ruta no implementada de forma específica en la maqueta, pero respondida para no romper la UI.",
    })


@app.api_route("/fhir/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def fhir_fallback(path: str, request: Request) -> JSONResponse:
    payload: Any = None
    try:
        payload = await request.json()
    except Exception:
        payload = None
    return JSONResponse({
        "resourceType": "OperationOutcome",
        "ok": True,
        "modo": "mock-fallback",
        "endpoint": f"/fhir/{path}",
        "method": request.method,
        "payload_recibido": payload,
    })
